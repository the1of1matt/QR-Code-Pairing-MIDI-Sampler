//
// dawDetector.js
//
// Detects whether FL Studio or Ableton Live is currently running on this
// Mac, using the process list — the only supported, sandbox-safe way to do
// this from Electron/Node. There is no public macOS API for "is app X
// currently receiving MIDI from device Y" — that state lives entirely
// inside FL Studio's / Ableton's own preferences and isn't exposed to
// other processes. See the note at the bottom of this file for exactly
// what this can and can't tell you.
//

const { exec } = require('child_process');

// Process names as they actually appear in `ps` output on macOS.
// FL Studio for Mac runs as "FL64" (legacy builds also show "FL Studio 20/21").
// Ableton Live's process is literally named "Live".
const DAW_SIGNATURES = {
  'FL Studio': [/\bFL64\b/i, /\bFL Studio\b/i, /\bFruityLoops\b/i],
  'Ableton Live': [/\bLive\b(?!\s*Text)/, /\bAbleton Live\b/i]
};

function listRunningProcessNames() {
  return new Promise((resolve) => {
    // -A: all processes, -c: command name only (no args), -o comm: just the
    // command column. This is a normal, unprivileged process listing — no
    // elevated permissions or sandboxed-app entitlement needed.
    exec('ps -A -c -o comm=', { timeout: 3000 }, (err, stdout) => {
      if (err || !stdout) { resolve([]); return; }
      resolve(stdout.split('\n').map((s) => s.trim()).filter(Boolean));
    });
  });
}

async function detectRunningDAWs() {
  const procs = await listRunningProcessNames();
  const result = {};
  for (const [dawName, patterns] of Object.entries(DAW_SIGNATURES)) {
    result[dawName] = procs.some((p) => patterns.some((re) => re.test(p)));
  }
  return result; // e.g. { 'FL Studio': false, 'Ableton Live': true }
}

module.exports = { detectRunningDAWs };

//
// LIMITATION (documented here rather than only in prose, so it stays next
// to the code it applies to):
//
// This can tell you "FL Studio's process is running" / "Ableton's process
// is running." It CANNOT tell you whether that DAW has actually enabled
// "MG Controller MIDI" as an input in its own MIDI settings — that
// configuration lives inside each DAW's private preferences file/in-memory
// state and is not exposed by any public macOS or DAW API. CoreMIDI itself
// has no concept of "which app is listening to which port" that's queryable
// from outside. The practical effect: this detector is a status hint
// ("looks like FL Studio is open") for the tray/status window, not a
// guarantee that MIDI is actually routed. The actual proof that routing
// works is the "Last MIDI Message" indicator already in the status window
// updating when pads are pressed — that's real, this is a convenience hint.
//
