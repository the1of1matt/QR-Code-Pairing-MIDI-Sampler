//
// midiBridge.js
//
// Owns the whole bridge: the CoreMIDI virtual output ("MG Controller MIDI"),
// the WebSocket server the iPad connects to, and Bonjour advertising for
// future zero-config discovery. Emits state changes so the renderer window
// can display them.
//
// SECURITY: every connection must present the current session pairing
// token (embedded in the QR code / shown in the status window) inside its
// first "hello" message within a short grace window, or it is dropped.
// All inbound messages are schema-validated before touching MIDI or state.
// Per-socket rate limiting and a hard client cap prevent flooding/abuse.
//

const os = require('os');
const crypto = require('crypto');
const midi = require('@julusian/midi');
const WebSocket = require('ws');
const QRCode = require('qrcode');
const { Bonjour } = require('bonjour-service');

const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

// --- Tunables ------------------------------------------------------------
const MAX_CLIENTS = 4;               // hard cap on simultaneous connections
const HELLO_GRACE_MS = 5000;         // time allowed to send a valid hello+token before drop
const TOKEN_TTL_MS = 12 * 60 * 60 * 1000; // pairing token rotates every 12h (or on demand)
const RATE_LIMIT_WINDOW_MS = 1000;   // token-bucket window
const RATE_LIMIT_MAX_MSGS = 200;     // max inbound messages per client per window (generous for pad spam)
const HEARTBEAT_INTERVAL_MS = 15000; // ws ping cadence
const HEARTBEAT_TIMEOUT_MS = 30000;  // drop if no pong within this long
const MAX_FRAME_BYTES = 4096;        // reject oversized frames outright
const MAX_NAME_LEN = 40;

function noteName(n) {
  const name = NOTE_NAMES[((n % 12) + 12) % 12];
  const octave = Math.floor(n / 12) - 1;
  return `${name}${octave}`;
}

function localIPv4() {
  const ifaces = os.networkInterfaces();
  const preferredOrder = Object.keys(ifaces).sort((a, b) => (a === 'en0' ? -1 : b === 'en0' ? 1 : 0));
  for (const name of preferredOrder) {
    for (const iface of ifaces[name] || []) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return null;
}

// --- Validation helpers ---------------------------------------------------
// Every inbound field is checked before use. Anything malformed is dropped
// silently (no error echoed back — don't give a malicious client oracle
// feedback about what shape of payload we expect).

function isInt(v) { return typeof v === 'number' && Number.isFinite(v) && Math.floor(v) === v; }
function inRange(v, lo, hi) { return isInt(v) && v >= lo && v <= hi; }

function sanitizeName(raw) {
  if (typeof raw !== 'string') return '';
  // Strip control characters, cap length, trim.
  return raw.replace(/[\u0000-\u001F\u007F]/g, '').trim().slice(0, MAX_NAME_LEN);
}

function validateMessage(msg) {
  if (!msg || typeof msg !== 'object' || Array.isArray(msg)) return null;
  if (typeof msg.type !== 'string') return null;

  switch (msg.type) {
    case 'hello':
      return {
        type: 'hello',
        name: sanitizeName(msg.name),
        token: typeof msg.token === 'string' ? msg.token.slice(0, 128) : ''
      };
    case 'noteOn':
    case 'noteOff':
      if (!inRange(msg.note, 0, 127)) return null;
      if (msg.channel !== undefined && !inRange(msg.channel, 1, 16)) return null;
      if (msg.velocity !== undefined && !inRange(msg.velocity, 0, 127)) return null;
      return { type: msg.type, note: msg.note, channel: msg.channel, velocity: msg.velocity };
    case 'cc':
      if (!inRange(msg.controller, 0, 127)) return null;
      if (!inRange(msg.value, 0, 127)) return null;
      if (msg.channel !== undefined && !inRange(msg.channel, 1, 16)) return null;
      return { type: 'cc', controller: msg.controller, value: msg.value, channel: msg.channel };
    case 'pitchBend':
      if (!inRange(msg.value, 0, 16383)) return null;
      if (msg.channel !== undefined && !inRange(msg.channel, 1, 16)) return null;
      return { type: 'pitchBend', value: msg.value, channel: msg.channel };
    default:
      return null; // unknown type — reject rather than silently ignore-and-continue
  }
}

// Simple fixed-window token bucket per socket.
class RateLimiter {
  constructor(max, windowMs) { this.max = max; this.windowMs = windowMs; this.count = 0; this.windowStart = Date.now(); }
  allow() {
    const now = Date.now();
    if (now - this.windowStart > this.windowMs) { this.windowStart = now; this.count = 0; }
    this.count += 1;
    return this.count <= this.max;
  }
}

class MIDIBridge {
  constructor({ port, virtualPortName, onStatus, onMessage, onError }) {
    this.port = port;
    this.virtualPortName = virtualPortName;
    this.onStatus = onStatus || (() => {});
    this.onMessage = onMessage || (() => {});
    this.onError = onError || (() => {});

    this.output = null;
    this.wss = null;
    this.bonjourInstance = null;
    this.bonjourService = null;
    this.refreshTimer = null;
    this.heartbeatTimer = null;

    /** @type {Map<WebSocket, ClientInfo>} */
    this.clients = new Map();

    this.sessionToken = this._generateToken();
    this.tokenIssuedAt = Date.now();

    this.state = {
      status: 'disconnected',
      connectedDeviceName: '—',
      connectionType: '—',
      macIP: localIPv4() || 'Unavailable',
      port: this.port,
      virtualMidiActive: false,
      lastMessage: '—',
      qrDataUrl: null,
      pairingToken: this.sessionToken,
      clientCount: 0,
      lastError: null
    };
  }

  getState() {
    return this.state;
  }

  // Lets the user manually force a new pairing token (e.g. "Regenerate QR"
  // button) without restarting the whole bridge.
  rotateToken() {
    this.sessionToken = this._generateToken();
    this.tokenIssuedAt = Date.now();
    this.state.pairingToken = this.sessionToken;
    // Existing authenticated clients are NOT kicked — rotation only affects
    // new pairing attempts. This avoids dropping an in-progress performance.
    this._emitStatus();
  }

  start() {
    this._createVirtualPort();
    try {
      this._startWebSocketServer();
    } catch (err) {
      this._reportFatal(`Could not start pairing server on port ${this.port}: ${err.message}`);
      return;
    }
    this._advertiseBonjour();
    this._emitStatus();
    this.refreshTimer = setInterval(() => {
      // Rotate the token automatically if it's aged out.
      if (Date.now() - this.tokenIssuedAt > TOKEN_TTL_MS) this.rotateToken();
      this._emitStatus();
    }, 5000);
    this.heartbeatTimer = setInterval(() => this._heartbeat(), HEARTBEAT_INTERVAL_MS);
  }

  stop() {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    try { this.wss && this.wss.close(); } catch (e) { /* noop */ }
    try { this.output && this.output.closePort(); } catch (e) { /* noop */ }
    try {
      if (this.bonjourInstance) {
        this.bonjourInstance.unpublishAll(() => this.bonjourInstance.destroy());
      }
    } catch (e) { /* noop */ }
  }

  // --- Setup -----------------------------------------------------------

  _generateToken() {
    return crypto.randomBytes(9).toString('base64url'); // short, QR-friendly
  }

  _createVirtualPort() {
    try {
      this.output = new midi.Output();
      this.output.openVirtualPort(this.virtualPortName);
      this.state.virtualMidiActive = true;
      console.log(`[MGMIDIBridge] Virtual MIDI port "${this.virtualPortName}" created.`);
    } catch (err) {
      console.error('[MGMIDIBridge] Failed to create virtual MIDI port:', err);
      this.state.virtualMidiActive = false;
      this.state.lastError = 'Could not create the virtual MIDI port. Another app may be using the same name.';
    }
  }

  _startWebSocketServer() {
    // Construction can throw synchronously (e.g. EADDRINUSE surfaces async
    // via 'error', but a bad port number or permission issue can throw here
    // too) — caller wraps this in try/catch.
    this.wss = new WebSocket.Server({ port: this.port, maxPayload: MAX_FRAME_BYTES });

    this.wss.on('connection', (socket, req) => {
      if (this.clients.size >= MAX_CLIENTS) {
        // Connection throttling: refuse beyond the cap with a clean close
        // code rather than accepting and silently dropping messages.
        try { socket.close(1013, 'Too many connections'); } catch (e) { /* noop */ }
        return;
      }

      // Reduce latency on the underlying TCP socket for real-time MIDI.
      try { if (req.socket && req.socket.setNoDelay) req.socket.setNoDelay(true); } catch (e) { /* noop */ }

      const ip = (req.socket.remoteAddress || 'unknown').replace('::ffff:', '');
      const client = {
        name: 'iPad Controller',
        ip,
        connectedAt: Date.now(),
        authenticated: false,
        isAlive: true,
        heldNotes: new Set(), // "channel:note" — used to send All Notes Off on drop
        limiter: new RateLimiter(RATE_LIMIT_MAX_MSGS, RATE_LIMIT_WINDOW_MS)
      };
      this.clients.set(socket, client);
      console.log(`[MGMIDIBridge] Connection opened from ${ip} (unauthenticated)`);

      // Require a valid hello+token within the grace window or drop.
      const helloTimer = setTimeout(() => {
        if (!client.authenticated) {
          console.log(`[MGMIDIBridge] Dropping ${ip}: no valid pairing token within grace period`);
          try { socket.close(4001, 'Pairing timeout'); } catch (e) { /* noop */ }
        }
      }, HELLO_GRACE_MS);

      socket.on('pong', () => { client.isAlive = true; });

      socket.on('message', (raw) => {
        if (!client.limiter.allow()) {
          // Rate-limited: drop the message. Repeated abuse closes the socket.
          client._rateStrikes = (client._rateStrikes || 0) + 1;
          if (client._rateStrikes > 5) {
            try { socket.close(1008, 'Rate limit exceeded'); } catch (e) { /* noop */ }
          }
          return;
        }

        let parsed;
        try {
          parsed = JSON.parse(raw.toString());
        } catch (e) {
          return; // malformed JSON — ignore
        }
        const msg = validateMessage(parsed);
        if (!msg) return; // failed schema validation — ignore, no feedback given

        if (msg.type === 'hello') {
          this._handleHello(msg, socket, client, helloTimer);
          return;
        }

        if (!client.authenticated) return; // MIDI messages before auth are dropped
        this._handleMidiMessage(msg, client);
      });

      socket.on('close', () => {
        clearTimeout(helloTimer);
        this._releaseHeldNotes(client);
        this.clients.delete(socket);
        console.log(`[MGMIDIBridge] Client disconnected: ${ip}`);
        this._updateConnectionState();
      });

      socket.on('error', (err) => {
        console.error('[MGMIDIBridge] Socket error:', err.message);
        clearTimeout(helloTimer);
        this._releaseHeldNotes(client);
        this.clients.delete(socket);
        this._updateConnectionState();
      });
    });

    this.wss.on('error', (err) => {
      console.error('[MGMIDIBridge] WebSocket server error:', err.message);
      this._reportFatal(`Pairing server error: ${err.message}`);
    });

    console.log(`[MGMIDIBridge] WebSocket server listening on port ${this.port}`);
  }

  _handleHello(msg, socket, client, helloTimer) {
    if (msg.token !== this.sessionToken) {
      // Wrong/missing token — do not authenticate. Let the grace timer drop
      // the connection rather than closing immediately, so a client that
      // sends hello before the token (race condition) gets one more chance
      // within the window instead of being punished for ordering.
      console.log(`[MGMIDIBridge] Rejected hello from ${client.ip}: invalid pairing token`);
      return;
    }
    clearTimeout(helloTimer);
    client.authenticated = true;
    if (msg.name) client.name = msg.name;
    console.log(`[MGMIDIBridge] Client authenticated: ${client.name} (${client.ip})`);
    this._updateConnectionState();
  }

  _advertiseBonjour() {
    try {
      this.bonjourInstance = new Bonjour();
      this.bonjourService = this.bonjourInstance.publish({
        name: 'MG MIDI Bridge',
        type: 'mgmidibridge',
        port: this.port,
        txt: { app: 'MG MIDI Controller' }
      });
      console.log('[MGMIDIBridge] Bonjour service advertised (_mgmidibridge._tcp).');
    } catch (err) {
      console.error('[MGMIDIBridge] Bonjour advertise failed:', err);
    }
  }

  // --- Heartbeat / stale connection detection ---------------------------

  _heartbeat() {
    for (const [socket, client] of this.clients.entries()) {
      if (!client.authenticated) continue;
      if (client.isAlive === false) {
        // No pong since last ping — treat as dead (covers backgrounded/
        // suspended Safari tabs and silent network drops that never fire
        // a close event).
        console.log(`[MGMIDIBridge] Heartbeat timeout for ${client.ip}, terminating`);
        this._releaseHeldNotes(client);
        this.clients.delete(socket);
        try { socket.terminate(); } catch (e) { /* noop */ }
        continue;
      }
      client.isAlive = false;
      try { socket.ping(); } catch (e) { /* noop */ }
    }
    this._updateConnectionState();
  }

  // --- Connection / message handling -----------------------------------

  _updateConnectionState() {
    const authed = [...this.clients.values()].filter(c => c.authenticated);
    this.state.clientCount = authed.length;
    if (authed.length > 0) {
      const names = authed.map(c => `${c.name} (${c.ip})`).join(', ');
      this.state.status = 'connected';
      this.state.connectedDeviceName = authed.length === 1 ? names : `${authed.length} devices: ${names}`;
      this.state.connectionType = 'Wi-Fi';
    } else {
      this.state.status = 'disconnected';
      this.state.connectedDeviceName = '—';
      this.state.connectionType = '—';
    }
    this._emitStatus();
  }

  _handleMidiMessage(msg, client) {
    switch (msg.type) {
      case 'noteOn': {
        const ch = msg.channel || 1;
        this._sendRaw(0x90, ch, msg.note, msg.velocity ?? 100);
        client.heldNotes.add(`${ch}:${msg.note}`);
        this._describe(`Note ON  ${noteName(msg.note)}  Velocity ${msg.velocity ?? 100}  Ch${ch}`);
        break;
      }
      case 'noteOff': {
        const ch = msg.channel || 1;
        this._sendRaw(0x80, ch, msg.note, msg.velocity ?? 0);
        client.heldNotes.delete(`${ch}:${msg.note}`);
        this._describe(`Note OFF ${noteName(msg.note)}  Ch${ch}`);
        break;
      }
      case 'cc':
        this._sendRaw(0xB0, msg.channel || 1, msg.controller, msg.value);
        this._describe(`CC ${msg.controller}  Value ${msg.value}  Ch${msg.channel || 1}`);
        break;
      case 'pitchBend': {
        const v = msg.value;
        const lsb = v & 0x7f;
        const msb = (v >> 7) & 0x7f;
        this._sendRaw(0xe0, msg.channel || 1, lsb, msb);
        this._describe(`Pitch Bend ${v}  Ch${msg.channel || 1}`);
        break;
      }
      default:
        break;
    }
  }

  // Sends Note Off for anything a client left held when it disconnects, so
  // a dropped connection (backgrounded app, Wi-Fi loss) never leaves a
  // stuck note ringing in the DAW.
  _releaseHeldNotes(client) {
    if (!client || !client.heldNotes || client.heldNotes.size === 0) return;
    for (const key of client.heldNotes) {
      const [ch, note] = key.split(':').map(Number);
      this._sendRaw(0x80, ch, note, 0);
    }
    client.heldNotes.clear();
  }

  _sendRaw(statusBase, channel, data1, data2) {
    if (!this.output) return;
    const ch = Math.max(1, Math.min(16, channel || 1)) - 1;
    const status = statusBase | ch;
    this.output.sendMessage([status, (data1 ?? 0) & 0x7f, (data2 ?? 0) & 0x7f]);
  }

  _describe(text) {
    this.state.lastMessage = text;
    this.onMessage(text);
  }

  _reportFatal(message) {
    this.state.lastError = message;
    this.onError(message);
    this._emitStatus();
  }

  async _emitStatus() {
    this.state.macIP = localIPv4() || 'Unavailable';
    this.state.pairingToken = this.sessionToken;
    if (this.state.macIP !== 'Unavailable') {
      try {
        this.state.qrDataUrl = await QRCode.toDataURL(
          `ws://${this.state.macIP}:${this.port}?t=${this.sessionToken}`,
          { margin: 1, width: 180, color: { dark: '#dde2e8', light: '#00000000' } }
        );
      } catch (e) {
        // non-fatal — QR just won't render this cycle
      }
    }
    this.onStatus(this.state);
  }
}

module.exports = { MIDIBridge };
