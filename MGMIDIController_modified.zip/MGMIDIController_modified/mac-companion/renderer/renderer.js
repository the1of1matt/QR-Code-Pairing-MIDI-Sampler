function applyState(state) {
  document.getElementById('status').textContent =
    state.status === 'connected' ? '🟢 Connected' : '🔴 Disconnected';
  document.getElementById('device').textContent = state.connectedDeviceName || '—';
  document.getElementById('connType').textContent = state.connectionType || '—';
  document.getElementById('macIP').textContent = state.macIP || '—';
  document.getElementById('port').textContent = state.port;
  document.getElementById('pairToken').textContent = state.pairingToken || '—';
  document.getElementById('virtualMidi').textContent =
    `MG Controller MIDI ${state.virtualMidiActive ? 'Active' : 'Inactive'}`;
  document.getElementById('lastMessage').textContent = state.lastMessage || '—';

  const qr = document.getElementById('qr');
  if (state.qrDataUrl) qr.src = state.qrDataUrl;

  const banner = document.getElementById('errorBanner');
  if (state.lastError) {
    banner.textContent = '⚠ ' + state.lastError;
    banner.style.display = 'block';
  } else {
    banner.style.display = 'none';
  }
}

function applyDawStatus(status) {
  const flEl = document.getElementById('dawFl');
  const abEl = document.getElementById('dawAbleton');
  if (flEl) flEl.textContent = status['FL Studio'] ? '🟢 Running' : '⚪ Not running';
  if (abEl) abEl.textContent = status['Ableton Live'] ? '🟢 Running' : '⚪ Not running';
}

window.bridgeAPI.onStatus((state) => applyState(state));
window.bridgeAPI.onMessage((text) => {
  document.getElementById('lastMessage').textContent = text;
});
window.bridgeAPI.onDawStatus((status) => applyDawStatus(status));

window.bridgeAPI.getState().then(applyState);

document.getElementById('rotateBtn').addEventListener('click', () => {
  window.bridgeAPI.rotateToken().then(applyState);
});
